#
# $Id$
#
# (c) 2003-2004 Morgan Stanley and Co.
# See ..../src/LICENSE for terms of distribution.
#

package AFS::Object::Transaction;

use strict;

our @ISA = qw(AFS::Object);
our $VERSION = '1.9';

1;
